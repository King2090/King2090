<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <h1 align="center"> MADARA MD </h1>


<a><img src='https://telegra.ph/file/e1fd045abc25ebcc215c3.jpg'/></a>
      
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=AM+MADARA+MD+CREATED+BY+BRYANT)](https://git.io/typing-svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 
<p align="center"> MADARA MD 😈, A Simple WhatsApp user BOT, Created by Ibrahim Tech.
</p>
<p align="center">


  <a href="https://ibb.co/N6NMDtn"><img src="https://telegra.ph/file/3c753002fab985c1cb1e7.jpg" alt="01" border="0" /></a>                     
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <h1 align="center">  SCAN SESSION </h1>
 

[PAIRING CODE]  ***[`TAP HERE TO SCAN PAIRING CODE`](https://bmw-code-app-c1168f4953cd.herokuapp.com/pair)***


  
 [QR] ***[`TAP HERE TO SCAN QR`](https://bmw-code-app-c1168f4953cd.herokuapp.com/qr)***


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
## Support ❣️❣️❣️❣️
## Join my channel for updates and get free cc
<a href="https://whatsapp.com/channel/0029VaZuGSxEawdxZK9CzM0Y" target="_blank">
    <img alt="whatsapp Group" src="https://chat.whatsapp.com/HsPiKU0POmU6Pbg4SLwi90.io/badge/ Whatsapp Support Channel -https://whatsapp.com/channel/0029VacpEdXIt5rqKLB9nC1L" />
  </a>
</p>


HOW TO REACH THE OWNER? 
 
   
   <a href="https://wa.me/message/+94 78 917 8807">
    <img src="https://telegra.ph/file/04da72e0bc56e64748969.jpg" />
  </a>&nbsp;&nbsp;
   <a

    ## Ask any thing
<a><img src='https://telegra.ph/file/f97fcf9569780b65c2065.png'/></a>


## STEPS TO DEPLOY YOUR BOT


1, Star the repo up there then click Here To  [`FORK`](https://github.com/King2090/King2090/fork)

2, 



3, CONNECT TO WHATSAPP WITH PAIRING CODE OR QR



4, TAP DEPLOY.., AND DEPLOY IT ON HEROKU 

## 𝘾𝙇𝙄𝘾𝙆 𝗢𝗡 HEROKU TO DEPLOY 




 <h1 align="center">

  ***[`TAP HERE TO DEPLOY ON HEROKU`](https://dashboard.heroku.com/new?template=https://github.com/King2090/MADARA-MD)***







  ***<p align="center"><a href="https://bmw-code-app-c1168f4953cd.herokuapp.com/">
 <img src="https://img.shields.io/badge/TAP%20HERE%20TO%20OPEN%20BRYANT%20TECH%20APP-Yellow?style=for-the-badge&logo=MADARA MD" width="220" height="38.45"/></a></p>***



<a><img src='https://telegra.ph/file/46e78b097c0c83f59e9eb.mp4'
   
  




## Contributes
## UMAR
## ABRAHAM 
## BRYAN TECH

Contributions to *MADARA_MD* are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.
## THANKS TO [GOD]

## License

The *MADARA MD* is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the *MADARA-MD*  to enhance your Whatsapp more enjoyable
☣Powered by Bryant tech

<a><img src='.https://telegra.ph/file/c57b58a5b4b199e815586.jpg'/></a>



<a><img src='https://telegra.ph/file/069aca41bcddbd67de484.mp4'/></a>
